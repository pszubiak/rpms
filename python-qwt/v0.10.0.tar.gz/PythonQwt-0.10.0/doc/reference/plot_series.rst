.. automodule:: qwt.plot_series
