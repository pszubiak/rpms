.. automodule:: qwt.plot_directpainter
