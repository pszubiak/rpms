Plot widget fundamentals
------------------------

.. automodule:: qwt.plot

.. automodule:: qwt.plot_canvas

Plot items
----------

.. automodule:: qwt.plot_grid

.. automodule:: qwt.plot_curve

.. automodule:: qwt.plot_marker

Additional plot features
------------------------

.. automodule:: qwt.legend

.. automodule:: qwt.color_map

.. automodule:: qwt.plot_renderer
