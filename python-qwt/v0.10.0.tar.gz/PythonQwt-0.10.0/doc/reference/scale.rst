Scales
------

.. automodule:: qwt.scale_widget

.. automodule:: qwt.scale_div

.. automodule:: qwt.scale_engine

.. automodule:: qwt.scale_draw
