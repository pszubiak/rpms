.. automodule:: qwt.toqimage
