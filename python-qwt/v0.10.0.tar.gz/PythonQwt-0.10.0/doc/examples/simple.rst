Really simple demo
~~~~~~~~~~~~~~~~~~

.. image:: /../qwt/tests/data/simple.png

.. literalinclude:: /../qwt/tests/simple.py
   :start-after: SHOW
