Event filter demo
~~~~~~~~~~~~~~~~~

.. image:: /../qwt/tests/data/eventfilter.png

.. literalinclude:: /../qwt/tests/eventfilter.py
   :start-after: SHOW
