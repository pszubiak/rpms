Error bar demo
~~~~~~~~~~~~~~

.. image:: /../qwt/tests/data/errorbar.png

.. literalinclude:: /../qwt/tests/errorbar.py
   :start-after: SHOW
