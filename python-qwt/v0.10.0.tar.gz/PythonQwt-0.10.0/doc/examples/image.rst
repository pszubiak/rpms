Image plot demo
~~~~~~~~~~~~~~~

.. image:: /../qwt/tests/data/image.png

.. literalinclude:: /../qwt/tests/image.py
   :start-after: SHOW
