Data demo
~~~~~~~~~

.. image:: /../qwt/tests/data/data.png

.. literalinclude:: /../qwt/tests/data.py
   :start-after: SHOW
