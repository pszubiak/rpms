Curve benchmark demo 1
~~~~~~~~~~~~~~~~~~~~~~

.. image:: /../qwt/tests/data/curvebenchmark1.png

.. literalinclude:: /../qwt/tests/curvebenchmark1.py
   :start-after: SHOW
