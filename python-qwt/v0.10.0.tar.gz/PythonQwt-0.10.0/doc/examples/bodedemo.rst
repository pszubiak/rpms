Bode demo
~~~~~~~~~

.. image:: /../qwt/tests/data/bodedemo.png

.. literalinclude:: /../qwt/tests/bodedemo.py
   :start-after: SHOW
