Map demo
~~~~~~~~

.. image:: /../qwt/tests/data/mapdemo.png

.. literalinclude:: /../qwt/tests/mapdemo.py
   :start-after: SHOW
