Log curve plot demo
~~~~~~~~~~~~~~~~~~~

.. image:: /../qwt/tests/data/logcurve.png

.. literalinclude:: /../qwt/tests/logcurve.py
   :start-after: SHOW
