Multi demo
~~~~~~~~~~

.. image:: /../qwt/tests/data/multidemo.png

.. literalinclude:: /../qwt/tests/multidemo.py
   :start-after: SHOW
