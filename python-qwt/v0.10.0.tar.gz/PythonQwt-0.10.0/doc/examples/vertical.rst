Vertical plot demo
~~~~~~~~~~~~~~~~~~

.. image:: /../qwt/tests/data/vertical.png

.. literalinclude:: /../qwt/tests/vertical.py
   :start-after: SHOW
