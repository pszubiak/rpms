Cartesian demo
~~~~~~~~~~~~~~

.. image:: /../qwt/tests/data/cartesian.png

.. literalinclude:: /../qwt/tests/cartesian.py
   :start-after: SHOW
