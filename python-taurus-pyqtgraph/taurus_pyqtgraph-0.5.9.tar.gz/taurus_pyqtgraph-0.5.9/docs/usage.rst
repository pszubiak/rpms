=====
Usage
=====

To use taurus_pyqtgraph in a project::

    import taurus.qt.qtgui.tpg


Or, to use it independently of Taurus:

    import taurus_pyqtgraph

