# Change Log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).
This file follows the formats and conventions from [keepachangelog.com]

Since changes in this pre-1.0.0 stage of the project will be fast, 
this changelog won't be properly updated for now.
For progress, keep track of the checklist in the `README.md` file.

[Unreleased]


[keepachangelog.com]: http://keepachangelog.com
[TEP17]: https://github.com/taurus-org/taurus/pull/452
[Unreleased]: https://gitlab.com/taurus-org/taurus_pyqtgraph/-/tree/main




