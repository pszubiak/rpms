.. automodule:: guiqwt.shapes
