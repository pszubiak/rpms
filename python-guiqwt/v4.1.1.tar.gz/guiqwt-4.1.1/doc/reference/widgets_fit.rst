.. automodule:: guiqwt.widgets.fit
