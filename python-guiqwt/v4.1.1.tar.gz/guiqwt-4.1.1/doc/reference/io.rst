.. automodule:: guiqwt.io
