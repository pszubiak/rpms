.. automodule:: guiqwt.annotations
