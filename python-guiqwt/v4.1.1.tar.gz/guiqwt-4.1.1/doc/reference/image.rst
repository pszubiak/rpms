.. automodule:: guiqwt.image
