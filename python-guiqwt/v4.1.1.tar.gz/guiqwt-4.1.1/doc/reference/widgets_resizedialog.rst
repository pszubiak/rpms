.. automodule:: guiqwt.widgets.resizedialog
