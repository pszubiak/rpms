.. automodule:: guiqwt.label
