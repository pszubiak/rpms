.. automodule:: guiqwt.plot
