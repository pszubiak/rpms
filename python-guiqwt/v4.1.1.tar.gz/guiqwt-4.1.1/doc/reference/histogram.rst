.. automodule:: guiqwt.histogram
