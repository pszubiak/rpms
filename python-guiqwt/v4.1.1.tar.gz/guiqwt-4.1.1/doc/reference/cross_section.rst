.. automodule:: guiqwt.cross_section
