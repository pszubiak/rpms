.. automodule:: guiqwt.curve
