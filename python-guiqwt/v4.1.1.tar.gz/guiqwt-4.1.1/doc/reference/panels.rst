.. automodule:: guiqwt.panels
