.. automodule:: guiqwt.tools
