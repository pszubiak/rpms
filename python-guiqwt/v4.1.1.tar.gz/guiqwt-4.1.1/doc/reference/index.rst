Reference
=========

guiqwt API:

.. toctree::
    :maxdepth: 2
    
    pyplot
    widgets_fit
    plot
    builder
    panels
    signals
    baseplot
    curve
    image
    histogram
    cross_section
    annotations
    shapes
    label
    tools
    styles
    io
    widgets_resizedialog
    widgets_rotatecrop
