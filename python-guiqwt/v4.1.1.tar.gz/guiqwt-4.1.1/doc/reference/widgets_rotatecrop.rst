.. automodule:: guiqwt.widgets.rotatecrop
