.. automodule:: guiqwt.signals
