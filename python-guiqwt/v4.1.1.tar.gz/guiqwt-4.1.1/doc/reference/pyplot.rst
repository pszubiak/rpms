.. automodule:: guiqwt.pyplot
