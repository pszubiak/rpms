.. automodule:: guiqwt.builder
