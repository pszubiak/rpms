.. automodule:: guiqwt.styles
