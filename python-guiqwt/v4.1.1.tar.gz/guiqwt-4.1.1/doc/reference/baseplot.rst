.. automodule:: guiqwt.baseplot
