#!/bin/sh
python tests/tests.py
