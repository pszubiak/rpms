R""(

# Examples

* Check out the source code of the `dwarffs` flake and build it:

  ```console
  # nix flake clone dwarffs --dest dwarffs
  # cd dwarffs
  # nix build
  ```

# Description

This command performs a Git or Mercurial clone of the repository
containing the source code of the flake *flake-url*.

)""
