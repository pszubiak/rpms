# Supported Platforms

Nix is currently supported on the following platforms:

  - Linux (i686, x86\_64, aarch64).

  - macOS (x86\_64, aarch64).
