# Release 1.5.2 (2013-05-13)

This is primarily a bug fix release. It has contributions from Eelco
Dolstra, Lluís Batlle i Rossell and Shea Levy.
