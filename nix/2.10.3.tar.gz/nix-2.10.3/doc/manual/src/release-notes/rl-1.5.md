# Release 1.5 (2013-02-27)

This is a brown paper bag release to fix a regression introduced by the
hard link security fix in 1.4.
