\--help

\--version

\--verbose

\-v

\--quiet

\--log-format

format

\--no-build-output

\-Q

\--max-jobs

\-j

number

\--cores

number

\--max-silent-time

number

\--timeout

number

\--keep-going

\-k

\--keep-failed

\-K

\--fallback

\--readonly-mode

\-I

path

\--option

name

value
