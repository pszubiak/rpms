#pragma once

namespace nix {

enum RepairFlag : bool { NoRepair = false, Repair = true };

}
