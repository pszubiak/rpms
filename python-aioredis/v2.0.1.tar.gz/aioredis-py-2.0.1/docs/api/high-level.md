# High Level APIs

## Exceptions

::: aioredis.exceptions

## Client

::: aioredis.client

## Lock

::: aioredis.lock

## Sentinel

::: aioredis.sentinel
