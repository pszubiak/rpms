.. automodule:: guidata.qthelpers
   :members:
