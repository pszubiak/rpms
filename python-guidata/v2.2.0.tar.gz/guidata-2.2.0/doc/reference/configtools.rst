.. automodule:: guidata.configtools
   :members:
