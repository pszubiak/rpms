.. automodule:: guidata.disthelpers
   :members:
