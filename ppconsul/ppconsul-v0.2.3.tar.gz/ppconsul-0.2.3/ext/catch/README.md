This directory contains [Catch2](https://github.com/catchorg/Catch2) unit test framework.
