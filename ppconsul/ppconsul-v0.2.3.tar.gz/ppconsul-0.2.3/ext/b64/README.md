This directory contains files from [libb64](http://libb64.sourceforge.net/) library for base64 encoding/decoding.
