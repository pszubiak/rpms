This directory contains files from [modified version of json11](https://github.com/oliora/json11) library.
It was derived from original [json11](https://github.com/dropbox/json11) library.
