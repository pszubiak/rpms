class LibClass1:
    
    def verify_libclass1(self):
        return 'LibClass 1 works'
        

class LibClass2:

    def verify_libclass2(self):
        return 'LibClass 2 works also'
    