def deprecated():
    """*DEPRECATED*"""


def deprecated_with_message():
    """*DEPRECATED for some good reason!* Yes it is. For sure."""


def no_deprecation_whatsoever():
    pass


def silent_deprecation():
    """*Deprecated* but not yet loudly.

    RF and Libdoc don't consider this being deprecated.
    """
