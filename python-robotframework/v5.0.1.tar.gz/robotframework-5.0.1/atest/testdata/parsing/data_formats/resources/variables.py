file_var1 = -314
file_var2 = 'file variable 2'
LIST__file_listvar = [True, 3.14, 'Hello, world!!']
escaping = '-c:\\temp-\t-\x00-${x}-'
