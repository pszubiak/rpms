def hello():
    print('Hello from lib2')

def kw_from_lib2():
    pass
