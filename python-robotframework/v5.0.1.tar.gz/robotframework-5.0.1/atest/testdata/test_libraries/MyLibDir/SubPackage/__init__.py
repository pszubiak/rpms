class SubPackage:

    def keyword_in_mylibdir_subpackage_class(self):
        pass
