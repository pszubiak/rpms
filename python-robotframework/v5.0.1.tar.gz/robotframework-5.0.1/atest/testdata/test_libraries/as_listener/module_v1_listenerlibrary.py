class Listener:

    def close(self):
        pass

class Listener2:

    def close(self):
        pass


ROBOT_LIBRARY_LISTENER = [Listener(), Listener2()]
