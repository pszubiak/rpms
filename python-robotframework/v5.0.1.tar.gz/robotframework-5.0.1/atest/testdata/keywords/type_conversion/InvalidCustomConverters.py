ROBOT_LIBRARY_CONVERTERS = 666


def keyword_in_library_with_invalid_converters(arg: int):
    assert arg == ROBOT_LIBRARY_CONVERTERS
