from operator import eq

length = len
print = print
