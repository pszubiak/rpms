# Release 0.8.1 (2005-04-13)

This is a bug fix release.

  - Patch downloading was broken.

  - The garbage collector would not delete paths that had references
    from invalid (but substitutable) paths.
