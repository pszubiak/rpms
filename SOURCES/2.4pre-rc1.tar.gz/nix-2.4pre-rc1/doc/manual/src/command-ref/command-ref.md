This section lists commands and options that you can use when you work
with Nix.
