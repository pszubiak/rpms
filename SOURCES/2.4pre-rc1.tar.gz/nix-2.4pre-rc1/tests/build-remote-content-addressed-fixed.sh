source common.sh

file=build-hook-ca-fixed.nix

source build-remote.sh
