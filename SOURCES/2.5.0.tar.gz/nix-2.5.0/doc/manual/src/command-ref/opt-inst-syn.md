\--prebuilt-only

\-b

\--attr

\-A

\--from-expression

\-E

\--from-profile

path
