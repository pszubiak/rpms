class SameNamesAsInBuiltIn:
    
    def noop(self):
        """Using this keyword without libname causes an error"""