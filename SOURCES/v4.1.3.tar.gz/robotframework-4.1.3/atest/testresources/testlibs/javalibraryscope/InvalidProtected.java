package javalibraryscope;

public class InvalidProtected extends BaseLib{
	
	protected static String ROBOT_LIBRARY_SCOPE = "global"; 
	
}