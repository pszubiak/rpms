list1 = [1, 2, 3, 4, 'foo', 'bar']
dictionary1 = {'a': 1}
dictionary2 = {'a': 1, 'b': 2}
