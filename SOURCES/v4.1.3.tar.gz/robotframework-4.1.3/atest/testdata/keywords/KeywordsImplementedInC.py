from __future__ import print_function

from operator import eq

length = len
print = print
