class Lib:

    def hello(self):
        print('Hello from lib1')

    def kw_from_lib1(self):
        pass
