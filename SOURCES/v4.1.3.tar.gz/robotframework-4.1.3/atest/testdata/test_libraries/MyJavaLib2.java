public class MyJavaLib2 {
	
	public String keywordInMyJavaLib2(String arg) {
		return "Moi " + arg + "!";
	}
}