LIST__illegal_values = (u'illegal:\x00\x08\x0B\x0C\x0E\x1F',
                        u'more:\uFFFE\uFFFF')
