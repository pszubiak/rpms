SUITE = SUITE_1 = "suite1"

