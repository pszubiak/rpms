/**
 * No inits here!
 */
public class NoArgConstructor {

    public NoArgConstructor() {
    }

    private NoArgConstructor(String foo) {
    }

    /**
     * The only lonely keyword.
     */
    public void keyword(String arg1, int arg2) {
    }
}
