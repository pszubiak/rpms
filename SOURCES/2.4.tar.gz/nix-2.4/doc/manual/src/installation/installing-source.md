# Installing Nix from Source

If no binary package is available, you can download and compile a source
distribution.
