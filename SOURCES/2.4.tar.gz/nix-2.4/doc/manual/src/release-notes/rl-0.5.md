# Release 0.5 and earlier

Please refer to the Subversion commit log messages.
