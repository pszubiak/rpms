R""(

# Description

`nix nar` provides several subcommands for creating and inspecting
*Nix Archives* (NARs).

# File format

For the definition of the NAR file format, see Figure 5.2 in
https://edolstra.github.io/pubs/phd-thesis.pdf.

)""
