## Synopsis

**lowdown** is a fork of [hoedown](https://github.com/hoedown/hoedown),
although the parser and front-ends have changed significantly.

For stable releases, documentation, and general information, please visit
https://kristaps.bsd.lv/lowdown.

## License

All sources use the ISC license.
See the [LICENSE.md](LICENSE.md) file for details.
