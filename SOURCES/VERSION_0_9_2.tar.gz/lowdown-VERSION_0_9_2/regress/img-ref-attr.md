
a ![b][cdef]

[cdef]: foo.jpg { width=50% .class #id }

