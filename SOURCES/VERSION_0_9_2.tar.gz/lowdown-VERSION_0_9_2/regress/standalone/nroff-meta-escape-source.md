source: .ab~cde
.fgh

foo bar
