section: .ab~cde
.fgh

foo bar
