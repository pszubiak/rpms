title: ab~cde\{foo}$bar

foo bar
