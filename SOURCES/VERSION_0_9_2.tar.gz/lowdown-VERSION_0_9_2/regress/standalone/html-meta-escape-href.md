css: foo&bar"foo".css

hello, world
