"(Hello, world.)"
