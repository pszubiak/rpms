window.addEventListener('load', function() {
	'use strict';
	hljs.initHighlighting();
});
