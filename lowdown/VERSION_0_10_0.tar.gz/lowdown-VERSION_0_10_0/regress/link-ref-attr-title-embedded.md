
a [b][cdef]

[cdef]: foo.com "title "foobar" { .class }

