date: .ab~cde
.fgh

foo bar
