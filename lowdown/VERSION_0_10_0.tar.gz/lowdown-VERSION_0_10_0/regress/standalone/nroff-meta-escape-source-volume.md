source: *&^(*&^asdfsad
volume: .ab~cde
.fgh
.fgh

foo bar
