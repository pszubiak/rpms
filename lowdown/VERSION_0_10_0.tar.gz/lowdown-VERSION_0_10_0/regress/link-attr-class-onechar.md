
link [text](address){ . cls }
