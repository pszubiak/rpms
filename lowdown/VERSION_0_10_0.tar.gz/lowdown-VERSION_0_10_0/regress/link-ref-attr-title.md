
a [b][cdef]

[cdef]: foo.com "title" { .class }

