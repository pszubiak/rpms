
a [b][cdef]

[cdef]: foo.com
(hello, world) { .class }

