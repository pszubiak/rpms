
a [b][cdef]

[cdef]: foo.com { .class }

