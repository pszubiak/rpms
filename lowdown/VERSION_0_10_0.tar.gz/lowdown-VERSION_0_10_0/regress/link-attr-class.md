
link [text](address){ .cls }
