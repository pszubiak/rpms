
a ![b][cdef]

[cdef]: foo.jpg

