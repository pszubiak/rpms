Reference
=========

QtBot
-----

.. module:: pytestqt.qtbot
.. autoclass:: QtBot

TimeoutError
------------

.. autoclass:: TimeoutError

SignalBlocker
-------------

.. module:: pytestqt.wait_signal
.. autoclass:: SignalBlocker

MultiSignalBlocker
------------------

.. autoclass:: MultiSignalBlocker

SignalEmittedError
------------------

.. autoclass:: SignalEmittedError

Record
------

.. module:: pytestqt.logging
.. autoclass:: Record

qapp fixture
------------

.. module:: pytestqt.plugin
.. autofunction:: qapp
.. autofunction:: qapp_args
