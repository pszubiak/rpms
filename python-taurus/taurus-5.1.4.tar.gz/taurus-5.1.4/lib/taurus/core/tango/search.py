from taurus.core.util.log import deprecated as __deprecated

__deprecated(
    dep="taurus.core.tango.search",
    alt="taurus.core.util.fandango_search",
    rel="4.1.2",
)

from taurus.core.util.fandango_search import *  # noqa
