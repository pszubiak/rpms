MyAttr = "eval:1"
My_Attr = "eval:foo=1;bar=2;foo+bar"
attr_1 = "tango:a/b/c/d"
attr_2 = "a/b/c/d"
attr1 = 'eval:"Hello_World!!"'
foo = "eval:/@Foo/True"
# 1foo = 'eval:2'
Foo = "eval:False"
res_attr = "res:attr1"
dev1 = "tango:a/b/c"  # invalid for attribute
dev2 = "eval:@foo"  # invalid for attribute
